# --- clase que hereda de frame
# --- grid para la geometría

import tkinter as tk
from tkinter import ttk

class CreaMarco(ttk.Frame):
    def __init__(self, padre=None, titulo =''):     #--- recibe como parámetros un form contenedor y un título
        super().__init__(padre)
        self.padre = padre
        self.columnconfigure(0, weight=1)   # --- 1: tamaño modificable
        self.rowconfigure(0, weight=1)      # --- 1: tamaño modificable
        self.grid(column=0, row=0, padx=(50,50), pady=(10,10), sticky= tk.S+tk.E+tk.N+tk.W)  # --- ubicación del frame en el formulario padre

        self.crear_controles(titulo)

    def crear_controles(self, titulo):
        self.lblTitulo = ttk.Label(self, text=titulo)

        self.btn_saludo = ttk.Button(self)       #--- el padre es un frame
        self.btn_saludo["text"] = "Hola todos\n(Haz Click!)"
        self.btn_saludo["command"] = self.saluda

        self.btn_salir = ttk.Button(self, text="QUIT",
                                   command=self.padre.destroy)  #--- se cierra el form padre   fg="red",

        # ubicamos dentro del marco, los controles creados
        self.lblTitulo.grid(row=0, column = 0, sticky= tk.W+tk.E)
        self.btn_saludo.grid(row=1, column=0, sticky=tk.S)
        self.btn_salir.grid(row=2,column=0, sticky= tk.S+tk.E)



    def saluda(self):
        print("Estoy aquí ...!")

if __name__ == '__main__':
    form1 = tk.Tk()             #--- creamos un formulario principal o raíz
    form1.title('Con grid como gestor de Geometría')
    form1.resizable(1,1)
    form1.columnconfigure(0, weight=1)   # --- 1: tamaño modificable
    form1.rowconfigure(0, weight=1)      # --- 1: tamaño modificable

    CreaMarco(padre=form1, titulo='frame 1')    #--- creamos un marco dentro del formulario raíz
    form1.mainloop()
