from tkinter import *

form1 = Tk()
form1.resizable(0, 1)     #--- 0, 0 tamaño no modificable  Horiz, Vert

marco1 = Frame(form1)
marco1.grid(column=0, row=0, padx=(50, 50), pady=(10, 10))

etiqueta = Label(marco1, text="Valor")
etiqueta.grid(column=2, row=2)
form1.mainloop()

