# --- clase que hereda de frame
# --- pack    para la geometría

import tkinter as tk

class CreaMarco(tk.Frame):
    def __init__(self, padre=None, titulo =''):     #--- recibe como parámetro un form contenedor
        super().__init__(padre)
        self.padre = padre
        self.pack(side='top')
        self.crear_controles(titulo)

    def crear_controles(self, titulo):
        self.lblTitulo = tk.Label(self, text=titulo)
        self.btn_saludo = tk.Button(self)       #--- el padre es un frame
        self.btn_saludo["text"] = "Hola todos\n(Haz Click!)"
        self.btn_saludo["command"] = self.saluda

        self.btn_salir = tk.Button(self, text="QUIT", fg="red",
                                   command=self.padre.destroy)  #--- se cierra el form padre

        #--- mostramos y ubicamos los controles creados:
        self.lblTitulo.pack()
        self.btn_saludo.pack(side="top")
        self.btn_salir.pack(side="bottom")



    def saluda(self):
        print("Hola .. Estoy aquí ...!")
        #print(self.btn_saludo.config('text'))


if __name__ == '__main__':
    form1 = tk.Tk()
    CreaMarco(padre=form1, titulo='frame 1')
    #CreaMarco(padre=form1, titulo='frame 2')

    form1.mainloop()


'''https://docs.python.org/3/library/tkinter.html   25.1.2.2'''
