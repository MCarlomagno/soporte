'''Ejemplo donde usamos 3 botones y pasamos un valor predet a una etiqueta'''

from tkinter import *

def hacer_click(nro=0):
   try:
      # _valor = int(entrada_texto.get())
      # _valor = _valor * 5
      _valor = nro
      etiqueta2.config(text=_valor)
   except ValueError:
      etiqueta2.config(text="Introduce un numero!")


form1 = Tk()
form1.title("Mi segunda App Gráfica")
form1.columnconfigure(0, weight=1)
form1.rowconfigure(0, weight=1)


marco1 = Frame(form1)
marco1.grid(column=0, row=0, padx=(50, 50), pady=(10, 10))
marco1.columnconfigure(0, weight=1)
marco1.rowconfigure(0, weight=1)

etiqueta1 = Label(marco1, text="Valor")
etiqueta2 = Label(marco1, text="")

boton1 = Button(marco1, text="OK 1!", command= lambda: hacer_click(1))
boton2 = Button(marco1, text="OK 2!", command= lambda: hacer_click(2))
boton3 = Button(marco1, text="OK 3!", command= lambda: hacer_click(3))

#--- ubicamos los controles creados
etiqueta1.grid(column=1, row=0, sticky=W)
etiqueta2.grid(column=2, row=0, sticky=W)
boton1.grid(column=1, row=1)
boton2.grid(column=1, row=2)
boton3.grid(column=1, row=3)

form1.mainloop()

#valor = ""
#entrada_texto = Entry(vp, width=10, textvariable=valor)
#entrada_texto.grid(column=2, row=1)
