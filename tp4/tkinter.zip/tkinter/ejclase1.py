# --- tomar un dato y mostrarlo
# --- un entry y un label
# --- Clase que hereda de Form

import tkinter as tk
from tkinter.messagebox import showinfo

#--- Crea un formulario, con sus controles
#---
class MiForm(tk.Tk):
    def __init__(self):
        super().__init__()          #---  Tk()
        self.title('Convertidor')
        self.creaControles(self)

    def creaControles(self, padre):
        lblTitulo = tk.Label(padre, text = 'Hola' )
        lblTitulo.pack()



if __name__ == '__main__':
    oform = MiForm()
    oform.mainloop()

    #--- forma sencilla de enviar un mensaje al usuario
    showinfo('Aviso','El formulario se ha cerrado!')    #--- sintaxis: showinfo('Título','Mensaje a mostrar')

