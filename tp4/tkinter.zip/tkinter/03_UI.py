from tkinter import *


def click():
    cVar = str(numVar.get())
    print("Edad: " + cVar)

frm1 = Tk()
lblNum = Label(frm1, text="Ingrese su edad")
numVar = IntVar()
numVar.set(23)
txtNum = Entry(frm1, textvariable=numVar)
btnListo = Button(frm1, text="Ingresar Valor", command=click)

lblNum.pack()
txtNum.pack()
btnListo.pack()

frm1.mainloop()



