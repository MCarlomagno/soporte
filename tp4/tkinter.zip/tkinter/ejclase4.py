# --- clase que hereda de frame
# --- grid para la geometría

import tkinter as tk
from tkinter import ttk

def saluda():
    print("Estoy aquí ...!")


f1 = tk.Tk()

f1.columnconfigure(0, weight=1)   # --- 1: tamaño modificable
f1.rowconfigure(0, weight=1)      # --- 1: tamaño modificable
lblTitulo = tk.Label(f1, text='titulo')
lblTitulo.grid(row=0, column = 0, sticky= tk.W+tk.E)

btn_saludo = tk.Button(f1)       #--- el padre es un frame
btn_saludo["text"] = "Hola todos\n(Haz Click!)"

btn_saludo["command"] = saluda()
btn_saludo.grid(row=1, column=0)

btn_salir = tk.Button(f1, text="QUIT", command=f1.destroy)  #--- se cierra el form padre   fg="red",
btn_salir.grid(row=2,column=0, sticky= tk.S+tk.E)

f1.mainloop()

